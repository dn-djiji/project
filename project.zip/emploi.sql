-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 29 mai 2024 à 21:37
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `emploi`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', '123');

-- --------------------------------------------------------

--
-- Structure de la table `entreprise`
--

CREATE TABLE `entreprise` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `type` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `entreprise`
--

INSERT INTO `entreprise` (`id`, `name`, `address`, `type`, `email`, `password`, `role`) VALUES
(1, 'hp', 'usa', 'Public', 'hp@gmail.com', '1234', 'entreprise'),
(2, 'djihane', 'annaba', 'Public', 'jiji@gmail.com', '1234', 'entreprise'),
(3, 'djihane', 'usa', 'Privé', 'hhhh@gmail.com', '1234', 'entreprise');

-- --------------------------------------------------------

--
-- Structure de la table `offres`
--

CREATE TABLE `offres` (
  `id` int(11) NOT NULL,
  `nom_du_travail` varchar(100) NOT NULL,
  `salaire` int(11) NOT NULL,
  `localisation` varchar(100) NOT NULL,
  `start` varchar(50) NOT NULL,
  `end` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `offres`
--

INSERT INTO `offres` (`id`, `nom_du_travail`, `salaire`, `localisation`, `start`, `end`, `description`, `email`) VALUES
(5, 'JJJ', 0, 'ANNABA', '2024-05-28', '2024-06-01', ',fqf,qkfn', 'hp@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `id_offer` int(11) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `nom_du_travail` varchar(100) NOT NULL,
  `salaire` int(11) NOT NULL,
  `localisation` varchar(1001) NOT NULL,
  `start` varchar(100) NOT NULL,
  `end` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `email_entreprise` varchar(100) NOT NULL,
  `cv` text NOT NULL,
  `date_ent` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `orders`
--

INSERT INTO `orders` (`id`, `email`, `id_offer`, `status`, `nom_du_travail`, `salaire`, `localisation`, `start`, `end`, `description`, `email_entreprise`, `cv`, `date_ent`) VALUES
(1, 'hp@gmail.com', 1, 1, 'FNFN', 0, 'FFNKF', '2024-05-29', '2024-06-06', 'jfjfnf,,fq,QFFL?', 'hp@gmail.com', '', ''),
(2, 'hp@gmail.com', 1, NULL, 'FNFN', 0, 'FFNKF', '2024-05-29', '2024-06-06', 'jfjfnf,,fq,QFFL?', 'hp@gmail.com', '', ''),
(3, 'dendanidjihane23@gmail.com', 5, 1, 'JJJ', 0, 'ANNABA', '2024-05-28', '2024-06-01', ',fqf,qkfn', 'hp@gmail.com', '1717006834.png', '2024-05-30');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `adresse` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `competences` text DEFAULT NULL,
  `sexe` varchar(50) DEFAULT NULL,
  `experience` text DEFAULT NULL,
  `cv` text DEFAULT NULL,
  `niveau` varchar(100) DEFAULT NULL,
  `service_national` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `adresse`, `phone`, `competences`, `sexe`, `experience`, `cv`, `niveau`, `service_national`) VALUES
(18, 'Dendani دنداني', 'dendanidjihane23@gmail.com', '123', 'ANNABA', '0699332417', 'JGGJGJEGJER', 'Homme', '', '1717006834.png', 'Rien', 'Carte jaune'),
(19, 'djihane', 'LLLL@gmail.com', '1234', 'f', '0699332417', 'fz', 'Homme', 'JZEKGZ', '1717011223.png', 'M2', 'Carte jaune');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `entreprise`
--
ALTER TABLE `entreprise`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `offres`
--
ALTER TABLE `offres`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `entreprise`
--
ALTER TABLE `entreprise`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `offres`
--
ALTER TABLE `offres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
